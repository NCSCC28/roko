import { useEffect, useState } from 'react';
import { supabase, GitaVerse, BibleVerse, DailyVerse } from '../lib/supabase';
import { Sparkles, Volume2, Heart } from 'lucide-react';
import { useSpeech } from '../hooks/useSpeech';

export default function HomePage() {
  const [dailyVerse, setDailyVerse] = useState<{ verse: GitaVerse | BibleVerse; type: 'gita' | 'bible' } | null>(null);
  const [loading, setLoading] = useState(true);
  const { speak, isSpeaking } = useSpeech();

  useEffect(() => {
    loadDailyVerse();
  }, []);

  const loadDailyVerse = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data: dailyData } = await supabase
        .from('daily_verses')
        .select('*')
        .eq('date', today)
        .maybeSingle();

      if (dailyData) {
        if (dailyData.verse_type === 'gita') {
          const { data: verse } = await supabase
            .from('gita_verses')
            .select('*')
            .eq('id', dailyData.verse_id)
            .maybeSingle();
          if (verse) setDailyVerse({ verse, type: 'gita' });
        } else {
          const { data: verse } = await supabase
            .from('bible_verses')
            .select('*')
            .eq('id', dailyData.verse_id)
            .maybeSingle();
          if (verse) setDailyVerse({ verse, type: 'bible' });
        }
      }
    } catch (error) {
      console.error('Error loading daily verse:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSpeak = () => {
    if (!dailyVerse) return;

    if (dailyVerse.type === 'gita') {
      const verse = dailyVerse.verse as GitaVerse;
      speak(`${verse.transliteration}. ${verse.translation_en}`, 'en-US');
    } else {
      const verse = dailyVerse.verse as BibleVerse;
      speak(verse.text, 'en-US');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-4 tracking-tight">
            Sacred Texts Platform
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Explore timeless wisdom from the Bhagavad Gita and the Bible with voice-enabled reading and search.
          </p>
        </div>

        <div className="mb-12">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <Sparkles className="h-6 w-6 text-amber-600 dark:text-amber-500" />
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">Verse of the Day</h2>
            <Sparkles className="h-6 w-6 text-amber-600 dark:text-amber-500" />
          </div>

          {loading ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mx-auto mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mx-auto"></div>
              </div>
            </div>
          ) : dailyVerse ? (
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-shadow duration-300">
              {dailyVerse.type === 'gita' ? (
                <>
                  <div className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-2">
                    Bhagavad Gita {(dailyVerse.verse as GitaVerse).chapter}:{(dailyVerse.verse as GitaVerse).verse}
                  </div>
                  <p className="text-2xl font-serif text-gray-800 dark:text-gray-200 mb-4 leading-relaxed">
                    {(dailyVerse.verse as GitaVerse).sanskrit}
                  </p>
                  <p className="text-lg text-gray-600 dark:text-gray-400 italic mb-4">
                    {(dailyVerse.verse as GitaVerse).transliteration}
                  </p>
                  <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                    {(dailyVerse.verse as GitaVerse).translation_en}
                  </p>
                  {(dailyVerse.verse as GitaVerse).commentary && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                      {(dailyVerse.verse as GitaVerse).commentary}
                    </p>
                  )}
                </>
              ) : (
                <>
                  <div className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-2">
                    {(dailyVerse.verse as BibleVerse).book} {(dailyVerse.verse as BibleVerse).chapter}:{(dailyVerse.verse as BibleVerse).verse}
                  </div>
                  <p className="text-lg text-gray-700 dark:text-gray-300 leading-relaxed">
                    {(dailyVerse.verse as BibleVerse).text}
                  </p>
                </>
              )}
              <div className="mt-6 flex justify-center">
                <button
                  onClick={handleSpeak}
                  disabled={isSpeaking}
                  className="flex items-center space-x-2 px-6 py-3 bg-amber-600 hover:bg-amber-700 disabled:bg-gray-400 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <Volume2 className="h-5 w-5" />
                  <span className="font-medium">{isSpeaking ? 'Speaking...' : 'Listen'}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
              <p className="text-gray-600 dark:text-gray-400">No verse available for today.</p>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-8 mt-12">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-3">Bhagavad Gita</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
              Explore 700 verses of ancient wisdom from the sacred Hindu scripture. Learn about dharma, karma, and the path to spiritual enlightenment.
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              18 Chapters • Sanskrit & English
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105">
            <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-3">The Bible</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
              Discover verses from the Old and New Testament. Find comfort, guidance, and inspiration from sacred Christian texts.
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              66 Books • Old & New Testament
            </div>
          </div>
        </div>

        <div className="mt-12 bg-gradient-to-r from-amber-100 to-orange-100 dark:from-amber-900/20 dark:to-orange-900/20 rounded-2xl shadow-xl p-8">
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4 text-center">Features</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-white dark:bg-gray-800 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-3 shadow-md">
                <Volume2 className="h-8 w-8 text-amber-600 dark:text-amber-500" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Voice Reading</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Listen to verses with clear pronunciation</p>
            </div>
            <div className="text-center">
              <div className="bg-white dark:bg-gray-800 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-3 shadow-md">
                <Heart className="h-8 w-8 text-amber-600 dark:text-amber-500" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Save Favorites</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Bookmark verses for quick access</p>
            </div>
            <div className="text-center">
              <div className="bg-white dark:bg-gray-800 rounded-full h-16 w-16 flex items-center justify-center mx-auto mb-3 shadow-md">
                <Sparkles className="h-8 w-8 text-amber-600 dark:text-amber-500" />
              </div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Daily Inspiration</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">Receive new verses every day</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
