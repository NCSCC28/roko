import { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Search } from 'lucide-react';
import { useVoiceRecognition } from '../hooks/useVoiceRecognition';
import { useSpeech } from '../hooks/useSpeech';
import { supabase, GitaVerse, BibleVerse } from '../lib/supabase';

export default function VoiceAssistant() {
  const { startListening, stopListening, transcript, isListening } = useVoiceRecognition();
  const { speak, isSpeaking, stop } = useSpeech();
  const [response, setResponse] = useState('');
  const [searchResults, setSearchResults] = useState<(GitaVerse | BibleVerse)[]>([]);

  useEffect(() => {
    if (transcript) {
      processCommand(transcript);
    }
  }, [transcript]);

  const processCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes('search') || lowerCommand.includes('find')) {
      const searchTerm = lowerCommand.replace(/search|find/g, '').trim();
      await searchVerses(searchTerm);
    } else if (lowerCommand.match(/gita|chapter|verse/)) {
      const chapterMatch = lowerCommand.match(/chapter\s*(\d+)/);
      const verseMatch = lowerCommand.match(/verse\s*(\d+)/);

      if (chapterMatch && verseMatch) {
        await fetchGitaVerse(parseInt(chapterMatch[1]), parseInt(verseMatch[1]));
      } else {
        setResponse('Please specify both chapter and verse number. For example: "Gita chapter 2 verse 3"');
        speak('Please specify both chapter and verse number.');
      }
    } else if (lowerCommand.match(/bible|john|genesis|psalm|matthew/)) {
      const bookMatch = lowerCommand.match(/(john|genesis|psalm|matthew)/);
      const chapterMatch = lowerCommand.match(/chapter\s*(\d+)/);
      const verseMatch = lowerCommand.match(/verse\s*(\d+)/);

      if (bookMatch && chapterMatch && verseMatch) {
        await fetchBibleVerse(bookMatch[1], parseInt(chapterMatch[1]), parseInt(verseMatch[1]));
      } else {
        setResponse('Please specify book, chapter, and verse. For example: "John chapter 3 verse 16"');
        speak('Please specify book, chapter, and verse.');
      }
    } else {
      setResponse('I can help you search for verses or read specific verses. Try saying "search for love" or "Gita chapter 2 verse 3"');
      speak('I can help you search for verses or read specific verses.');
    }
  };

  const searchVerses = async (searchTerm: string) => {
    try {
      const { data: gitaData } = await supabase
        .from('gita_verses')
        .select('*')
        .or(`translation_en.ilike.%${searchTerm}%,transliteration.ilike.%${searchTerm}%,commentary.ilike.%${searchTerm}%`)
        .limit(5);

      const { data: bibleData } = await supabase
        .from('bible_verses')
        .select('*')
        .ilike('text', `%${searchTerm}%`)
        .limit(5);

      const results = [...(gitaData || []), ...(bibleData || [])];
      setSearchResults(results);

      if (results.length > 0) {
        setResponse(`Found ${results.length} verses matching "${searchTerm}"`);
        speak(`Found ${results.length} verses matching ${searchTerm}`);
      } else {
        setResponse(`No verses found matching "${searchTerm}"`);
        speak(`No verses found matching ${searchTerm}`);
      }
    } catch (error) {
      console.error('Search error:', error);
      setResponse('Sorry, there was an error searching for verses.');
      speak('Sorry, there was an error searching for verses.');
    }
  };

  const fetchGitaVerse = async (chapter: number, verse: number) => {
    try {
      const { data } = await supabase
        .from('gita_verses')
        .select('*')
        .eq('chapter', chapter)
        .eq('verse', verse)
        .maybeSingle();

      if (data) {
        setSearchResults([data]);
        setResponse(`Bhagavad Gita Chapter ${chapter}, Verse ${verse}`);
        speak(`Bhagavad Gita Chapter ${chapter}, Verse ${verse}. ${data.transliteration}. ${data.translation_en}`);
      } else {
        setResponse(`Could not find Gita chapter ${chapter}, verse ${verse}`);
        speak(`Could not find Gita chapter ${chapter}, verse ${verse}`);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      setResponse('Sorry, there was an error fetching the verse.');
      speak('Sorry, there was an error fetching the verse.');
    }
  };

  const fetchBibleVerse = async (book: string, chapter: number, verse: number) => {
    try {
      const bookName = book.charAt(0).toUpperCase() + book.slice(1);
      const { data } = await supabase
        .from('bible_verses')
        .select('*')
        .ilike('book', bookName)
        .eq('chapter', chapter)
        .eq('verse', verse)
        .maybeSingle();

      if (data) {
        setSearchResults([data]);
        setResponse(`${data.book} ${chapter}:${verse}`);
        speak(`${data.book} ${chapter}:${verse}. ${data.text}`);
      } else {
        setResponse(`Could not find ${bookName} chapter ${chapter}, verse ${verse}`);
        speak(`Could not find ${bookName} chapter ${chapter}, verse ${verse}`);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      setResponse('Sorry, there was an error fetching the verse.');
      speak('Sorry, there was an error fetching the verse.');
    }
  };

  const handleMicClick = () => {
    if (isListening) {
      stopListening();
    } else {
      setResponse('');
      setSearchResults([]);
      startListening();
    }
  };

  const readVerse = (verse: GitaVerse | BibleVerse) => {
    if ('sanskrit' in verse) {
      speak(`${verse.transliteration}. ${verse.translation_en}`);
    } else {
      speak(verse.text);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Voice Assistant</h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Ask me to search for verses or read specific passages
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <div className="flex flex-col items-center space-y-6">
            <button
              onClick={handleMicClick}
              className={`relative w-32 h-32 rounded-full flex items-center justify-center transition-all duration-300 ${
                isListening
                  ? 'bg-red-500 hover:bg-red-600 shadow-2xl scale-110'
                  : 'bg-gradient-to-br from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-xl'
              }`}
            >
              {isListening ? (
                <>
                  <MicOff className="h-12 w-12 text-white" />
                  <span className="absolute -bottom-2 -right-2 w-6 h-6 bg-red-600 rounded-full animate-ping"></span>
                </>
              ) : (
                <Mic className="h-12 w-12 text-white" />
              )}
            </button>

            <div className="text-center">
              <p className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {isListening ? 'Listening...' : 'Click to speak'}
              </p>
              {transcript && (
                <div className="bg-gray-100 dark:bg-gray-700 rounded-lg px-6 py-3 mb-4">
                  <p className="text-gray-700 dark:text-gray-300">
                    <span className="font-semibold">You said:</span> "{transcript}"
                  </p>
                </div>
              )}
              {response && (
                <div className="bg-purple-100 dark:bg-purple-900/30 rounded-lg px-6 py-3">
                  <p className="text-purple-900 dark:text-purple-300">{response}</p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Example commands:</h3>
            <ul className="space-y-2 text-gray-600 dark:text-gray-400">
              <li className="flex items-start space-x-2">
                <Search className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                <span>"Search for love"</span>
              </li>
              <li className="flex items-start space-x-2">
                <Search className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                <span>"Find verses about peace"</span>
              </li>
              <li className="flex items-start space-x-2">
                <Volume2 className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                <span>"Gita chapter 2 verse 3"</span>
              </li>
              <li className="flex items-start space-x-2">
                <Volume2 className="h-5 w-5 text-purple-500 mt-0.5 flex-shrink-0" />
                <span>"John chapter 3 verse 16"</span>
              </li>
            </ul>
          </div>
        </div>

        {searchResults.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">Results:</h2>
            {searchResults.map((verse) => (
              <div
                key={verse.id}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300"
              >
                {'sanskrit' in verse ? (
                  <>
                    <div className="text-sm font-semibold text-amber-600 dark:text-amber-500 mb-2">
                      Bhagavad Gita {verse.chapter}:{verse.verse}
                    </div>
                    <p className="text-xl font-serif text-gray-800 dark:text-gray-200 mb-2">
                      {verse.sanskrit}
                    </p>
                    <p className="text-gray-600 dark:text-gray-400 italic mb-2">
                      {verse.transliteration}
                    </p>
                    <p className="text-gray-700 dark:text-gray-300">{verse.translation_en}</p>
                  </>
                ) : (
                  <>
                    <div className="text-sm font-semibold text-blue-600 dark:text-blue-500 mb-2">
                      {verse.book} {verse.chapter}:{verse.verse}
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">{verse.text}</p>
                  </>
                )}
                <button
                  onClick={() => readVerse(verse)}
                  disabled={isSpeaking}
                  className="mt-4 flex items-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white rounded-lg transition-colors duration-200"
                >
                  <Volume2 className="h-4 w-4" />
                  <span>{isSpeaking ? 'Speaking...' : 'Listen'}</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
