import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface GitaVerse {
  id: string;
  chapter: number;
  verse: number;
  sanskrit: string;
  transliteration: string;
  translation_en: string;
  translation_hi: string;
  commentary: string;
  audio_url: string;
  created_at: string;
}

export interface BibleVerse {
  id: string;
  book: string;
  chapter: number;
  verse: number;
  text: string;
  testament: 'Old' | 'New';
  audio_url: string;
  created_at: string;
}

export interface UserFavorite {
  id: string;
  user_id: string;
  verse_type: 'gita' | 'bible';
  verse_id: string;
  created_at: string;
}

export interface DailyVerse {
  id: string;
  date: string;
  verse_type: 'gita' | 'bible';
  verse_id: string;
  created_at: string;
}
