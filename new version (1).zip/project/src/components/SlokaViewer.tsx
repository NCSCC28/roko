import { useState } from 'react';
import { useGita } from '../hooks/useGita';
import { Search, ChevronRight, Loader2 } from 'lucide-react';

export function SlokaViewer() {
  const [chapter, setChapter] = useState<number>(1);
  const [verse, setVerse] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'single' | 'chapter' | 'search'>('single');

  const {
    sloka,
    slokasByChapter,
    searchResults,
    loading,
    error,
    fetchSlokaByChapterVerse,
    fetchSlokasByChapter,
    performSearch,
  } = useGita();

  const handleFetchSloka = () => {
    setViewMode('single');
    fetchSlokaByChapterVerse(chapter, verse);
  };

  const handleFetchChapter = () => {
    setViewMode('chapter');
    fetchSlokasByChapter(chapter);
  };

  const handleSearch = () => {
    if (searchTerm.trim()) {
      setViewMode('search');
      performSearch(searchTerm);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Bhagavad Gita Slokas</h1>
          <p className="text-slate-600">
            Retrieve and explore slokas with translations and meanings
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Retrieve by Chapter & Verse</h2>
              <div className="flex gap-3 flex-wrap">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Chapter (1-18)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="18"
                    value={chapter}
                    onChange={(e) => setChapter(Math.max(1, Math.min(18, parseInt(e.target.value) || 1)))}
                    className="w-24 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Verse
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={verse}
                    onChange={(e) => setVerse(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-24 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="flex items-end gap-2">
                  <button
                    onClick={handleFetchSloka}
                    disabled={loading}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-slate-400 transition-colors flex items-center gap-2"
                  >
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ChevronRight className="w-4 h-4" />}
                    Get Sloka
                  </button>
                  <button
                    onClick={handleFetchChapter}
                    disabled={loading}
                    className="px-4 py-2 bg-slate-600 text-white rounded-lg hover:bg-slate-700 disabled:bg-slate-400 transition-colors"
                  >
                    Get Chapter
                  </button>
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Search Slokas</h2>
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search in translations and meanings..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <button
                  onClick={handleSearch}
                  disabled={loading || !searchTerm.trim()}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-slate-400 transition-colors"
                >
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {viewMode === 'single' && sloka && (
          <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
            <div className="border-b pb-4">
              <p className="text-sm font-semibold text-slate-600 mb-2">
                Chapter {sloka.chapter} • Verse {sloka.verse}
              </p>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">{sloka.sloka}</h2>
              <p className="text-lg text-slate-700 italic">{sloka.transliteration}</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">English Translation</h3>
                <p className="text-slate-700 leading-relaxed">{sloka.translation.english}</p>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 mb-2">Hindi Translation</h3>
                <p className="text-slate-700 leading-relaxed">{sloka.translation.hindi}</p>
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-4">
              <h3 className="font-semibold text-slate-900 mb-2">Word-by-Word Meaning</h3>
              <p className="text-slate-700 leading-relaxed text-sm">{sloka.meaning.wordByWord}</p>
            </div>

            {sloka.audio && (
              <div>
                <p className="text-sm font-semibold text-slate-600 mb-2">Audio</p>
                <audio controls className="w-full">
                  <source src={sloka.audio} type="audio/mpeg" />
                  Your browser does not support the audio element.
                </audio>
              </div>
            )}
          </div>
        )}

        {viewMode === 'chapter' && slokasByChapter && (
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">
              Chapter {chapter} • {slokasByChapter.length} Verses
            </h2>
            <div className="space-y-4">
              {slokasByChapter.map((s) => (
                <div
                  key={`${s.chapter}-${s.verse}`}
                  className="border rounded-lg p-4 hover:bg-slate-50 transition-colors"
                >
                  <p className="text-sm font-semibold text-slate-600 mb-1">
                    Chapter {s.chapter} • Verse {s.verse}
                  </p>
                  <p className="font-semibold text-slate-900 mb-2">{s.sanskrit}</p>
                  <p className="text-slate-600 text-sm">{s.translation_en}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {viewMode === 'search' && searchResults && searchResults.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">
              Search Results • {searchResults.length} matches
            </h2>
            <div className="space-y-4">
              {searchResults.map((s) => (
                <div
                  key={`${s.chapter}-${s.verse}`}
                  className="border rounded-lg p-4 hover:bg-slate-50 transition-colors"
                >
                  <p className="text-sm font-semibold text-slate-600 mb-1">
                    Chapter {s.chapter} • Verse {s.verse}
                  </p>
                  <p className="font-semibold text-slate-900 mb-2">{s.sanskrit}</p>
                  <p className="text-slate-600 text-sm">{s.translation_en}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {viewMode === 'search' && searchResults && searchResults.length === 0 && !loading && (
          <div className="bg-slate-50 rounded-lg p-8 text-center">
            <p className="text-slate-600">No results found for "{searchTerm}"</p>
          </div>
        )}
      </div>
    </div>
  );
}
