import { useState } from 'react';
import { Heart, Volume2, BookOpen, Book } from 'lucide-react';
import { useSpeech } from '../hooks/useSpeech';

export default function FavoritesPage() {
  const [favorites] = useState<never[]>([]);
  const { speak, isSpeaking } = useSpeech();

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center space-x-3 mb-8">
          <Heart className="h-10 w-10 text-rose-600 dark:text-rose-500" />
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">My Favorites</h1>
        </div>

        {favorites.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
            <Heart className="h-16 w-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-2">No favorites yet</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Start saving your favorite verses by clicking the heart icon on any verse
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4 flex items-center space-x-3">
                <BookOpen className="h-8 w-8 text-amber-600 dark:text-amber-500" />
                <div className="text-left">
                  <div className="font-semibold text-gray-900 dark:text-white">Bhagavad Gita</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Browse sacred verses</div>
                </div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 flex items-center space-x-3">
                <Book className="h-8 w-8 text-blue-600 dark:text-blue-500" />
                <div className="text-left">
                  <div className="font-semibold text-gray-900 dark:text-white">The Bible</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Explore scriptures</div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {favorites.map((favorite: never) => (
              <div
                key={favorite}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-2xl transition-all duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="text-sm font-semibold text-rose-600 dark:text-rose-500">
                    Favorite Verse
                  </div>
                  <div className="flex space-x-2">
                    <button
                      disabled={isSpeaking}
                      className="p-2 rounded-full bg-rose-100 dark:bg-rose-900/30 hover:bg-rose-200 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-500 transition-colors duration-200 disabled:opacity-50"
                      aria-label="Play audio"
                    >
                      <Volume2 className="h-5 w-5" />
                    </button>
                    <button
                      className="p-2 rounded-full bg-rose-600 hover:bg-rose-700 text-white transition-colors duration-200"
                      aria-label="Remove from favorites"
                    >
                      <Heart className="h-5 w-5 fill-current" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
